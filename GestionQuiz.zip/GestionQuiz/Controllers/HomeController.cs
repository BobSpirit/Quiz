﻿using GestionQuiz.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace GestionQuiz.Controllers
{
    public class HomeController : Controller
    {
        private readonly GestionQuizContext context;

        public HomeController(GestionQuizContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult NewQuiz()
        {
            var cat = context.Category;
            ViewBag.Categ = cat;
            ViewBag.style = "text-success";
            return View();
        }
        public IActionResult PasserQuiz(string username, string email)
        {
            if (username != null && email != null)
            {
                var quiz = context.Quiz.Where(c => c.UserName.Contains(username) && c.Email.Contains(email) && c.Answer.Count == 0).ToList();

                if (quiz.Count > 0)
                {
                    ViewBag.QuizIdent = $"{quiz.First().UserName} ({quiz.First().Email})";
                    ViewBag.style = "text-success";
                    return View(quiz);
                }
                else
                {
                    ViewBag.message = "Pas de résultats";
                    ViewBag.style = "text-danger";
                }
            }
            return View();
        }
        public IActionResult ReviewQuiz(string username = "", string email = "")

        {
            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(email))
            {
                var quiz = context.Quiz.Where(c => c.UserName.Contains(username) && c.Email.Contains(email) && c.Answer.Count > 0).ToList();

                if (quiz.Count > 0)
                {
                    ViewBag.QuizIdent = $"{quiz.First().UserName} ({quiz.First().Email})";
                    ViewBag.style = "text-success";
                    return View(quiz);
                }
                else
                {
                    ViewBag.message = "Pas de résultats";
                    ViewBag.style = "text-danger";
                }
            }
            return View();
        }

        // Fonction qui retourne un tableau en mélangeant les elements d'un tableau en param
        public static IEnumerable<T> Shuffle<T>(IEnumerable<T> source)
        {
            T[] elements = source.ToArray();
            Random rng = new Random();
            for (int i = elements.Length - 1; i > 0; i--)
            {
                int swapIndex = rng.Next(i + 1);
                yield return elements[swapIndex];
                elements[swapIndex] = elements[i];
            }
            yield return elements[0];
        }
        public IActionResult GenereQuiz()
        {
            Quiz newquiz = new Quiz(); // nouveau quiz

            foreach (var key in HttpContext.Request.Query.Keys)
            {
                StringValues someVal;
                int catId, nbQuest;
                bool success = Int32.TryParse(key, out catId);
                HttpContext.Request.Query.TryGetValue(key, out someVal);
                if (success)
                {
                    var questions = context.Question.Where(x => x.CategoryId == catId).ToList();
                    var rndQuest = Shuffle(questions).ToList();

                    nbQuest = questions.Count() < Int32.Parse(someVal) ? questions.Count() : Int32.Parse(someVal);

                    for (int i = 0; i < nbQuest; i++)
                    {
                        QuestionQuiz qq = new QuestionQuiz();
                        qq.QuestionId = rndQuest[i].QuestionId;
                        qq.QuizId = newquiz.QuizId;
                        newquiz.QuestionQuiz.Add(qq);
                    }
                }
                else
                {
                    if (key == "UserName")
                    {
                        newquiz.UserName = someVal;
                    }
                    else
                    {
                        newquiz.Email = someVal;
                    }
                }
            }
            context.Add<Quiz>(newquiz);
            context.SaveChanges();
            return View("Index");
        }
        public IActionResult AnswerToQuiz(int? quizId)
        {
            if (quizId != null)
            {
                Quiz quiz = context.Quiz.Find(quizId);
                Answer answers = context.Answer.Find(quizId);

                var qq = Shuffle(quiz.QuestionQuiz);
                var co = context.Option;

                List<Question> questions = new List<Question>();
                List<Option> options = new List<Option>();

                foreach (var quest in qq)
                {
                    questions.Add(context.Question.Find(quest.QuestionId));
                    foreach (var opt in co)
                    {
                        if (opt.QuestionId == quest.QuestionId)
                        {
                            options.Add(opt);
                        }
                    }
                }

                ViewBag.Quiz = quiz;
                ViewBag.Questions = questions;
                ViewBag.Options = options;
                return View();

            }

            return View("PasserQuiz");

        }
        public IActionResult SendAnswer(int quizId)
        {
            foreach (var key in HttpContext.Request.Query.Keys)
            {
                int isOption;
                bool success = Int32.TryParse(key, out isOption);
                StringValues someVal;
                HttpContext.Request.Query.TryGetValue(key, out someVal);

                if (success)
                {
                    Answer ans = new Answer
                    {
                        OptionId = Int32.Parse(someVal),
                        QuizId = quizId
                    };
                    context.Add<Answer>(ans);
                    context.SaveChanges();
                }

            }

            return View("Index");
        }
        public IActionResult ReviewAnswerToQuiz(int? quizId)
        {
            if (quizId != null)
            {
                Quiz quiz = context.Quiz.Find(quizId);

                var qq = quiz.QuestionQuiz;
                var co = context.Option;

                List<Question> questions = new List<Question>();
                List<Option> options = new List<Option>();

                foreach (var quest in qq)
                {
                    questions.Add(context.Question.Find(quest.QuestionId));
                    foreach (var opt in co)
                    {
                        if (opt.QuestionId == quest.QuestionId)
                        {
                            options.Add(opt);
                        }
                    }
                }
                ViewBag.NbQuestions = questions.Count();
                ViewBag.NbBonnesReponses = quiz.Answer.Where(b => b.Option.IsRight == true).Count();

                ViewBag.Quiz = quiz;
                ViewBag.Questions = questions;
                return View(options);

            }
            return View("Index");
        }

    }
}
