﻿using GestionQuiz.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GestionQuiz.Controllers
{
    public class GestionController : Controller
    {
        private readonly GestionQuizContext context;

        public GestionController(GestionQuizContext _context)
        {
            context = _context;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Quiz()
        {
            return View(context.Quiz);
        }
        public IActionResult Question()
        {
            return View(context.Question);
        }
        [HttpGet]
        public IActionResult AddQuestion()
        {
            ViewBag.Category = context.Category;
            return View();
        }

        [HttpPost]
        public IActionResult AddQuestion(String Text, int CategoryId)
        {
            Question quest = new Question()
            {
                Text = Text,
                CategoryId = CategoryId
            };

            context.Add<Question>(quest);
            context.SaveChanges();
            return RedirectToAction("Question");
        }
        
        public IActionResult QuestionsQuiz(int Id) // ID du Quiz
        {
            var questionQuiz = context.Quiz.Find(Id).QuestionQuiz;

            var questions = new List<Question>();

            foreach (var item in questionQuiz)
            {
                questions.Add(context.Question.Find(item.QuestionId));
            }

            return View(questions);
        }
                
        public IActionResult SingleQuestionOptions(int quizId, int questionID)
        {
            var questionQuiz = context.Quiz.Find(quizId).QuestionQuiz.Where(q => q.QuestionId == questionID);

            var options = new List<Option>();

            foreach (var item in questionQuiz)
            {
                options.Add(context.Option.Find(item.QuestionId));
            }

            return View(options);
        }

    }
}
