﻿function validFN(fn) {
    if (!isNaN(fn)) return alert(fn);
}
