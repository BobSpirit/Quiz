﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GestionQuiz.Models
{
    public partial class Quiz
    {
        public Quiz()
        {
            Answer = new HashSet<Answer>();
            QuestionQuiz = new HashSet<QuestionQuiz>();
        }

        public int QuizId { get; set; }
        [Required(ErrorMessage = "Champ obligatoire")] public string UserName { get; set; }
        [Required(ErrorMessage = "Champ obligatoire")] public string Email { get; set; }

        public virtual ICollection<Answer> Answer { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuiz { get; set; }
        
    }
}
