﻿using System;
using System.Collections.Generic;

namespace GestionQuiz.Models
{
    public partial class Option
    {
        public Option()
        {
            Answer = new HashSet<Answer>();
        }

        public int OptionId { get; set; }
        public string Text { get; set; }
        public bool? IsRight { get; set; }
        public int QuestionId { get; set; }

        public virtual Question Question { get; set; }
        public virtual ICollection<Answer> Answer { get; set; }
    }
}
