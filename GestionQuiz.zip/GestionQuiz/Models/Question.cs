﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GestionQuiz.Models
{
    public partial class Question
    {
        public Question()
        {
            Option = new HashSet<Option>();
            QuestionQuiz = new HashSet<QuestionQuiz>();
        }

        public int QuestionId { get; set; }

        [Required(ErrorMessage = "Champ obligatoire")] public string Text { get; set; }
        [Required(ErrorMessage = "Champ obligatoire")] public int CategoryId { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<Option> Option { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuiz { get; set; }
    }
}
