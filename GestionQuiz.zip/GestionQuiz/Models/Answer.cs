﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GestionQuiz.Models
{
    public partial class Answer
    {
        [Key]
        public int AnswerId { get; set; }
        [Required(ErrorMessage = "Champ obligatoire")] public int OptionId { get; set; }
        [Required(ErrorMessage = "Champ obligatoire")] public int QuizId { get; set; }

        public virtual Option Option { get; set; }
        public virtual Quiz Quiz { get; set; }
    }
}
