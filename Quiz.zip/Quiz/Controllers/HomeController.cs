﻿using Microsoft.AspNetCore.Mvc;
using Quiz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quiz.Controllers
{
    public class HomeController : Controller
    {
        readonly GestionQuizContext db = new GestionQuizContext();

        public IActionResult Index()
        {
            return View(db.Question);
        }

    }
}
