﻿using System;
using System.Collections.Generic;

namespace Quiz.Models
{
    public partial class Question
    {
        public Question()
        {
            Option = new HashSet<Option>();
            QuestionQuiz = new HashSet<QuestionQuiz>();
        }

        public int QuestionId { get; set; }
        public string Text { get; set; }
        public int CategoryId { get; set; }

        public virtual Category Category { get; set; }
        public virtual ICollection<Option> Option { get; set; }
        public virtual ICollection<QuestionQuiz> QuestionQuiz { get; set; }
    }
}
